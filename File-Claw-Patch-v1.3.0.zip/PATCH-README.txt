FILE CLAW — PATCH v1.3.0 (Loop 8)
Search Polish + PDF Reader Fixes + DOCX Zoom

HOW TO APPLY
1. Upload every folder/file from this zip into the GitHub repo root, keeping the
   exact structure (overwrite existing files when asked).
2. NEW files in this version (do not skip them):
   - app/src/main/java/com/example/core/search/FileSearchRanker.kt
   - app/src/main/java/com/example/core/format/DocxZoomPolicy.kt
   - app/src/test/java/com/example/core/search/FileSearchRankerTest.kt
   - app/src/test/java/com/example/core/format/DocxZoomPolicyTest.kt
3. No repo files must be deleted by this patch (root junk-cleanup list is in chat).
4. Version bump already inside app/build.gradle.kts (versionCode 3, versionName 1.3.0).
5. Build the APK with GitHub Actions (no local compile needed).

Full details: changelogs.md (v1.3.0 block). Next loop prompt: docs/prompts/NEXT_LOOP_PROMPT.md
